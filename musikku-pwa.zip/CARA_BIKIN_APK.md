# Cara Ubah Musikku Jadi APK (Tanpa Android Studio)

Paket ini isinya: `index.html`, `manifest.json`, `service-worker.js`, folder `icons/`.
Ini sudah jadi **PWA (Progressive Web App)** yang siap dibungkus jadi APK.

## Langkah 1 — Host filenya (gratis, pakai GitHub Pages)
PWABuilder butuh alamat/link hidup buat baca aplikasi kamu, jadi filenya perlu di-upload dulu:

1. Buat repo baru di GitHub (atau pakai akun yang sudah kamu pakai buat Endless Desert).
2. Upload semua file di folder ini (index.html, manifest.json, service-worker.js, icons/) ke repo itu — bisa lewat browser HP/laptop, tinggal drag & drop di halaman GitHub, nggak perlu command line.
3. Aktifkan GitHub Pages: Settings → Pages → Branch: main → Save.
4. Tunggu 1-2 menit, kamu akan dapat link seperti `https://namakamu.github.io/musikku/`.

## Langkah 2 — Generate APK di PWABuilder
1. Buka **https://www.pwabuilder.com** di browser.
2. Masukkan link GitHub Pages kamu tadi, klik **Start**.
3. PWABuilder bakal scan manifest & service worker-nya otomatis (sudah aku siapkan, harusnya langsung lolos "green" di semua checklist).
4. Klik tab **Android** → **Generate Package**.
5. Pilih tipe **APK** (bukan AAB, karena AAB itu khusus buat upload ke Play Store).
6. Download file APK-nya.

## Langkah 3 — Install ke HP
1. Pindahkan file `.apk` ke HP kamu (lewat kabel, atau upload ke Drive lalu download di HP).
2. Buka file-nya → kalau muncul peringatan "sumber tidak dikenal", izinkan install dari sumber ini (ini normal untuk APK di luar Play Store).
3. Selesai — sekarang Musikku jadi ikon app sendiri, bukan tab browser lagi.

## Yang perlu kamu tau soal daya tahan background
APK hasil PWABuilder ini jalan pakai **Trusted Web Activity** — mesinnya tetap Chrome, tapi dibungkus jadi app asli. Efeknya:
- ✅ Lebih tahan lama di background dibanding tab browser biasa (Android nggak gampang nge-kill app terinstal).
- ✅ Ikon sendiri, buka dari home screen, terasa kayak app beneran.
- ⚠️ Tapi ini **belum** pakai *foreground service* asli seperti Spotify — jadi kalau HP kamu benar-benar kehabisan RAM atau kamu paksa "Force Stop" dari Setelan, musiknya tetap bisa berhenti. Ini beda dengan "swipe dari recent apps" (yang sudah aman di app terinstal) — force stop manual tetap akan matiin.

Kalau ke depannya kamu mau upgrade lagi ke foreground service asli (level "nggak akan mati kecuali kamu force stop manual"), itu butuh sedikit kode native Kotlin/Java yang di-tempel lewat Android Studio — beda level effort, tapi bisa dikerjain bertahap kapan-kapan.
